# methods

This project tests your knowledge of built in ruby methods.
If you find that your solution to any problem is getting long and cumbersome you're probably missing a helpful builtin method.
You are encouraged to use google if you can't figure out which method to use.
You should be able to do each exercise, except maybe the last two, in one line.

This project has tests to help you check your answers.
To run the tests, first navigate to the root directory of the project and run `bundle install` to install rspec.
Then, each time you want to run the tests, run `bundle exec rspec`.
