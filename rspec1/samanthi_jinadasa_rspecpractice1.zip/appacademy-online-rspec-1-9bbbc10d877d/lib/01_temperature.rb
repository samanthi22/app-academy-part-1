def ftoc(temp)
    return (temp - 32)*(5.0/9)
end 

def ctof(temp)
    return temp*(9.0/5)+32
end